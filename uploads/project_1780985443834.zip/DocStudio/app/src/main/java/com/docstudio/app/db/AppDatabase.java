package com.docstudio.app.db;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Update;
import androidx.room.Delete;
import androidx.room.Query;
import androidx.room.OnConflictStrategy;

import java.util.List;

/**
 * DocStudio Room database.
 * Stores: library entries, bookmarks, notes/quotes, reading progress.
 */
@Database(
    entities = {
        AppDatabase.LibraryEntry.class,
        AppDatabase.Bookmark.class,
        AppDatabase.Note.class,
        AppDatabase.ReadingProgress.class
    },
    version = 1,
    exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {

    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(
                        context.getApplicationContext(),
                        AppDatabase.class,
                        "docstudio.db"
                    ).fallbackToDestructiveMigration().build();
                }
            }
        }
        return INSTANCE;
    }

    public abstract LibraryDao libraryDao();
    public abstract BookmarkDao bookmarkDao();
    public abstract NoteDao noteDao();
    public abstract ReadingProgressDao readingProgressDao();

    // ── ENTITIES ─────────────────────────────────────────────────────────────

    @Entity(tableName = "library")
    public static class LibraryEntry {
        @PrimaryKey(autoGenerate = true)
        public int id;
        public String filePath;       // absolute URI / path
        public String title;
        public String format;         // txt, pdf, epub, fb2, djvu, docx, etc.
        public String tags;           // comma-separated tags
        public long   addedAt;        // epoch millis
        public long   lastOpenedAt;   // epoch millis
        public int    totalPages;
        public long   readingTimeMs;  // cumulative reading time
    }

    @Entity(tableName = "bookmarks")
    public static class Bookmark {
        @PrimaryKey(autoGenerate = true)
        public int id;
        public String filePath;
        public int    page;           // 1-based page or position
        public int    scrollY;        // scroll position in pixels
        public String title;          // user-defined title
        public long   createdAt;
    }

    @Entity(tableName = "notes")
    public static class Note {
        @PrimaryKey(autoGenerate = true)
        public int id;
        public String filePath;
        public int    page;
        public String selectedText;   // the quoted/highlighted text
        public String noteText;       // user's annotation
        public String color;          // highlight color (hex)
        public long   createdAt;
        public long   updatedAt;
    }

    @Entity(tableName = "reading_progress")
    public static class ReadingProgress {
        @PrimaryKey
        public String filePath;       // unique per file
        public int    page;
        public int    scrollY;
        public long   lastReadAt;
        public int    totalPages;
        public long   readingTimeMs;
    }

    // ── DAOs ─────────────────────────────────────────────────────────────────

    @Dao
    public interface LibraryDao {
        @Insert(onConflict = OnConflictStrategy.REPLACE)
        void insert(LibraryEntry entry);

        @Update
        void update(LibraryEntry entry);

        @Delete
        void delete(LibraryEntry entry);

        @Query("SELECT * FROM library ORDER BY lastOpenedAt DESC")
        List<LibraryEntry> getAll();

        @Query("SELECT * FROM library WHERE format = :fmt ORDER BY lastOpenedAt DESC")
        List<LibraryEntry> getByFormat(String fmt);

        @Query("SELECT * FROM library WHERE tags LIKE '%' || :tag || '%'")
        List<LibraryEntry> getByTag(String tag);

        @Query("SELECT * FROM library WHERE filePath = :path LIMIT 1")
        LibraryEntry getByPath(String path);

        @Query("SELECT * FROM library WHERE title LIKE '%' || :q || '%' ORDER BY lastOpenedAt DESC")
        List<LibraryEntry> search(String q);
    }

    @Dao
    public interface BookmarkDao {
        @Insert(onConflict = OnConflictStrategy.REPLACE)
        void insert(Bookmark b);

        @Delete
        void delete(Bookmark b);

        @Query("SELECT * FROM bookmarks WHERE filePath = :path ORDER BY page ASC")
        List<Bookmark> getForFile(String path);

        @Query("DELETE FROM bookmarks WHERE filePath = :path")
        void deleteForFile(String path);
    }

    @Dao
    public interface NoteDao {
        @Insert(onConflict = OnConflictStrategy.REPLACE)
        long insert(Note n);

        @Update
        void update(Note n);

        @Delete
        void delete(Note n);

        @Query("SELECT * FROM notes WHERE filePath = :path ORDER BY page ASC, createdAt ASC")
        List<Note> getForFile(String path);

        @Query("SELECT * FROM notes WHERE filePath = :path AND page = :page ORDER BY createdAt ASC")
        List<Note> getForPage(String path, int page);

        @Query("SELECT * FROM notes ORDER BY createdAt DESC")
        List<Note> getAll();

        @Query("SELECT * FROM notes WHERE selectedText LIKE '%' || :q || '%' OR noteText LIKE '%' || :q || '%'")
        List<Note> search(String q);
    }

    @Dao
    public interface ReadingProgressDao {
        @Insert(onConflict = OnConflictStrategy.REPLACE)
        void save(ReadingProgress p);

        @Query("SELECT * FROM reading_progress WHERE filePath = :path LIMIT 1")
        ReadingProgress get(String path);

        @Query("UPDATE reading_progress SET readingTimeMs = readingTimeMs + :ms WHERE filePath = :path")
        void addTime(String path, long ms);
    }
}
