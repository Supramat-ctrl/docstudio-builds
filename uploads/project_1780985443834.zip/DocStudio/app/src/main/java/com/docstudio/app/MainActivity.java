package com.docstudio.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import com.docstudio.app.db.AppDatabase;

import nl.siegmann.epublib.epub.EpubReader;
import nl.siegmann.epublib.domain.Book;
import nl.siegmann.epublib.domain.Resource;
import nl.siegmann.epublib.domain.SpineReference;

import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.xmlpull.v1.XmlPullParser;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "DocStudio";

    // File size limits
    // PDF: PdfRenderer reads pages lazily — the file stays on disk, only 1 page
    //      in RAM at a time. 1 GB+ files are safe with lazy loading.
    // TXT/EPUB/FB2: text is loaded into Java String → limit to available RAM.
    // DOC: Apache POI loads the whole file into RAM → strict limit.
    private static final long MAX_TEXT_FILE_BYTES = 50L   * 1024 * 1024;  // 50 MB
    private static final long MAX_PDF_FILE_BYTES  = 2000L * 1024 * 1024;  // 2 GB — lazy load
    private static final long MAX_DOC_FILE_BYTES  = 20L   * 1024 * 1024;  // 20 MB (POI)

    // Lazy PDF loading: initial pages to render on open, rest loaded on scroll
    private static final int PDF_INITIAL_PAGES = 10;
    // How many pages to load per "load more" request
    private static final int PDF_LOAD_BATCH    = 10;

    WebView webView;
    private AppDatabase db;
    // [R5] dbExecutor already shut down in onDestroy ✓
    private final ExecutorService dbExecutor = Executors.newSingleThreadExecutor();
    private final Gson gson = new Gson();

    // ── Launchers ────────────────────────────────────────────────────────────
    ActivityResultLauncher<Intent> openAnyLauncher;
    ActivityResultLauncher<Intent> openImageLauncher;
    ActivityResultLauncher<Intent> saveTXTLauncher;
    ActivityResultLauncher<Intent> saveAsLauncher;
    ActivityResultLauncher<Intent> savePDFDocLauncher;

    // ── State ────────────────────────────────────────────────────────────────
    volatile String pendingSaveContent = null;
    volatile String pendingConvertText = null;
    volatile Uri    currentSaveUri     = null;
    volatile Uri    currentPDFUri      = null;
    volatile String currentFilePath    = null;
    volatile String currentFileFormat  = null;
    private volatile boolean pdfLoading = false; // [M3] block double-open

    // [R1] pdfPageTexts: limit to 50 pages to cap RAM usage
    private static final int PDF_MAX_TEXT_PAGES = 50;
    private final List<String> pdfPageTexts = new ArrayList<>();

    private Uri pendingViewUri = null;

    // ── PDF rendering constants ──────────────────────────────────────────────
    private static final int PDF_JPEG_QUALITY      = 80;  // [R9] was 92 → 80 saves ~25% RAM
    private static final int PDF_MAX_PREVIEW_PAGES = 500; // hard cap — lazy loads in batches
    private static final int PDF_BASE_WIDTH        = 720; // safe multi-page render

    private int pdfHiresWidth = 1080; // single-page zoom re-render, set in onCreate

    private int getHiresPdfWidth() {
        return pdfHiresWidth;
    }

    // ── DjVu native ──────────────────────────────────────────────────────────
    private boolean djvuLibLoaded = false;

    private boolean ensureDjVuLoaded() {
        if (!djvuLibLoaded) {
            djvuLibLoaded = universe.constellation.orion.viewer.djvu.DjvuDocument.loadLibrary();
            if (djvuLibLoaded) Log.d(TAG, "DjVu native library loaded");
            else                Log.w(TAG, "DjVu native library NOT available");
        }
        return djvuLibLoaded;
    }

    // ── TTS ──────────────────────────────────────────────────────────────────
    private TextToSpeech tts;
    private volatile boolean ttsReady    = false;
    private volatile boolean ttsSpeaking = false;

    // [M6] TTS chunk size — Android TTS is limited to ~4000 chars per utterance
    private static final int TTS_CHUNK_SIZE = 3000;

    // ── Timers ───────────────────────────────────────────────────────────────
    private long readingStartMs = 0;

    // ─────────────────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate");
        PDFBoxResourceLoader.init(getApplicationContext());
        db = AppDatabase.getInstance(this);

        webView = new WebView(this);
        setContentView(webView);

        // Pre-compute hires width on UI thread
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        pdfHiresWidth = Math.min(dm.widthPixels, 1440);
        Log.d(TAG, "pdfHiresWidth=" + pdfHiresWidth + " screenW=" + dm.widthPixels);

        setupWebView();
        setupLaunchers();
        setupBackHandler();
        setupTTS();

        webView.loadUrl("file:///android_asset/editor.html");

        Intent intent = getIntent();
        if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            pendingViewUri = intent.getData();
        }
    }

    @Override protected void onResume()  { super.onResume();  readingStartMs = System.currentTimeMillis(); }
    @Override protected void onPause()   { super.onPause();   saveReadingProgress(); }

    // [R5] Shutdown executor; [R5 confirmed] TTS released
    @Override
    protected void onDestroy() {
        Log.d(TAG, "onDestroy");
        if (tts != null) { tts.stop(); tts.shutdown(); tts = null; }
        dbExecutor.shutdown();
        super.onDestroy();
    }

    // ── TTS ──────────────────────────────────────────────────────────────────
    private void setupTTS() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) {
                Log.w(TAG, "TTS init failed, status=" + status);
                return;
            }
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) {
                    ttsSpeaking = true;
                    runOnUiThread(() -> webView.evaluateJavascript("window.onTTSStateChange(true)", null));
                }
                @Override public void onDone(String id) {
                    // Check if there are more chunks to speak
                    if (!speakNextChunk()) {
                        ttsSpeaking = false;
                        runOnUiThread(() -> webView.evaluateJavascript("window.onTTSStateChange(false)", null));
                    }
                }
                @Override public void onError(String id) {
                    ttsSpeaking = false;
                    Log.e(TAG, "TTS error for utterance: " + id);
                    runOnUiThread(() -> webView.evaluateJavascript("window.onTTSStateChange(false)", null));
                }
            });
            ttsReady = true;
            Log.d(TAG, "TTS ready");
        });
    }

    // [M6] TTS chunked speaking — Android TTS limit ~4000 chars
    private List<String> ttsChunks = new ArrayList<>();
    private int ttsChunkIndex = 0;

    private void startSpeaking(String text, Locale lang) {
        if (text == null || text.trim().isEmpty()) {
            showBridgeToast("Нет текста для воспроизведения");
            return;
        }
        if (!ttsReady) { showBridgeToast("TTS инициализируется, подождите"); return; }
        if (!applyTTSLocale(lang)) { showBridgeToast("Язык не поддерживается устройством"); return; }

        // Split into chunks of TTS_CHUNK_SIZE chars
        ttsChunks = splitIntoChunks(text, TTS_CHUNK_SIZE);
        ttsChunkIndex = 0;
        Log.d(TAG, "TTS: " + ttsChunks.size() + " chunks, lang=" + lang.getLanguage());
        speakNextChunk();
    }

    private boolean speakNextChunk() {
        if (ttsChunks == null || ttsChunkIndex >= ttsChunks.size()) {
            ttsChunks = new ArrayList<>();
            ttsChunkIndex = 0;
            return false;
        }
        String chunk = ttsChunks.get(ttsChunkIndex++);
        android.os.Bundle params = new android.os.Bundle();
        tts.speak(chunk, TextToSpeech.QUEUE_FLUSH, params,
            "docstudio_tts_" + ttsChunkIndex);
        return true;
    }

    private List<String> splitIntoChunks(String text, int chunkSize) {
        List<String> chunks = new ArrayList<>();
        int len = text.length();
        for (int i = 0; i < len; i += chunkSize) {
            chunks.add(text.substring(i, Math.min(i + chunkSize, len)));
        }
        return chunks;
    }

    private Locale detectLanguage(String text) {
        if (text == null || text.isEmpty()) return new Locale("ru", "RU");
        int cyrillic = 0, latin = 0;
        for (int i = 0; i < Math.min(text.length(), 500); i++) {
            char c = text.charAt(i);
            if (c >= 0x0400 && c <= 0x04FF) cyrillic++;
            else if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')) latin++;
        }
        return (cyrillic >= latin) ? new Locale("ru", "RU") : Locale.ENGLISH;
    }

    private boolean applyTTSLocale(Locale locale) {
        int r = tts.setLanguage(locale);
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            r = tts.setLanguage(Locale.ENGLISH);
            return r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED;
        }
        return true;
    }

    // ── WebView setup ─────────────────────────────────────────────────────────
    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);

        // [R2] Security: restrict file access to assets only
        s.setAllowFileAccess(true);           // needed to load assets/editor.html
        s.setAllowContentAccess(false);       // [R2] not needed → disabled
        s.setAllowFileAccessFromFileURLs(false);          // [R2] block cross-file access
        s.setAllowUniversalAccessFromFileURLs(false);     // [R2] block file→network access

        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW); // [R2] was ALWAYS_ALLOW
        s.setBuiltInZoomControls(false);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (pendingViewUri != null) {
                    openFileByUri(pendingViewUri);
                    pendingViewUri = null;
                }
            }

            // [R2+M4] Block navigation to any URL that is not our local editor
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.startsWith("file:///android_asset/")) {
                    return false; // allow our local HTML
                }
                Log.w(TAG, "Blocked WebView navigation to: " + url);
                return true; // block everything else
            }
        });

        webView.setWebChromeClient(new WebChromeClient());

        webView.setFindListener((activeMatchOrdinal, numberOfMatches, isDoneCounting) -> {
            if (isDoneCounting) {
                int current = numberOfMatches > 0 ? activeMatchOrdinal + 1 : 0;
                runOnUiThread(() ->
                    webView.evaluateJavascript(
                        "window.onSearchResults(" + current + "," + numberOfMatches + ")", null));
            }
        });

        webView.addJavascriptInterface(new EditorBridge(this), "AndroidBridge");
        Log.d(TAG, "WebView configured with security restrictions");
    }

    // ── Launchers ─────────────────────────────────────────────────────────────
    private void setupLaunchers() {
        openAnyLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (ok(result)) {
                    Uri uri = result.getData().getData();
                    // [R3] null check
                    if (uri == null) { Log.w(TAG, "openAny: null URI"); return; }
                    takePerm(uri, true, false);
                    openFileByUri(uri);
                }
            });

        openImageLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (ok(result)) {
                    Uri uri = result.getData().getData();
                    if (uri == null) { Log.w(TAG, "openImage: null URI"); return; }
                    takePerm(uri, true, false);
                    insertImageToEditor(uri);
                }
            });

        saveTXTLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (ok(result) && pendingSaveContent != null) {
                    Uri uri = result.getData().getData();
                    if (uri == null) return;
                    takePerm(uri, true, true);
                    currentSaveUri = uri;
                    String c = pendingSaveContent; pendingSaveContent = null;
                    saveTXTToUri(uri, c);
                }
            });

        saveAsLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (ok(result) && pendingSaveContent != null) {
                    Uri uri = result.getData().getData();
                    if (uri == null) return;
                    takePerm(uri, true, true);
                    currentSaveUri = uri;
                    String c = pendingSaveContent; pendingSaveContent = null;
                    saveTXTToUri(uri, c);
                }
            });

        savePDFDocLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(), result -> {
                if (ok(result) && pendingConvertText != null) {
                    Uri uri = result.getData().getData();
                    if (uri == null) return;
                    takePerm(uri, true, true);
                    String t = pendingConvertText; pendingConvertText = null;
                    generatePDFFromText(t, uri);
                }
            });
    }

    private boolean ok(androidx.activity.result.ActivityResult r) {
        return r.getResultCode() == Activity.RESULT_OK
            && r.getData() != null
            && r.getData().getData() != null;
    }

    private void setupBackHandler() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override public void handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack();
                else { setEnabled(false); getOnBackPressedDispatcher().onBackPressed(); }
            }
        });
    }

    // ── Universal file opener ─────────────────────────────────────────────────
    void openFileByUri(Uri uri) {
        // [R3] Null check
        if (uri == null) { Log.e(TAG, "openFileByUri: null URI"); return; }

        String mime = getContentResolver().getType(uri);
        String path = uri.toString();
        Log.d(TAG, "openFileByUri: " + path + " mime=" + mime);

        if (mime == null) {
            String p = uri.getPath() != null ? uri.getPath().toLowerCase() : "";
            if (p.endsWith(".pdf"))  mime = "application/pdf";
            else if (p.endsWith(".djvu") || p.endsWith(".djv")) mime = "image/vnd.djvu";
            else if (p.endsWith(".epub")) mime = "application/epub+zip";
            else if (p.endsWith(".fb2"))  mime = "application/x-fictionbook";
            else if (p.endsWith(".docx")) mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            else if (p.endsWith(".doc"))  mime = "application/msword";
            else if (p.endsWith(".odt"))  mime = "application/vnd.oasis.opendocument.text";
            else if (p.endsWith(".rtf"))  mime = "application/rtf";
            else if (p.endsWith(".md") || p.endsWith(".markdown")) mime = "text/markdown";
            else if (p.endsWith(".html") || p.endsWith(".htm")) mime = "text/html";
            else mime = "text/plain";
        }

        currentFilePath = path;

        // FIX-1.3/1.4: Notify JS of current document info (title, path, format)
        // so the logo dropdown and toolbar filename badge are populated.
        notifyDocInfo(uri, mime);

        // [R8] Check file size before opening
        if (!checkFileSizeAllowed(uri, mime)) return;

        if (mime.contains("pdf")) {
            currentPDFUri = uri; currentSaveUri = null;
            currentFileFormat = "pdf";
            synchronized (pdfPageTexts) { pdfPageTexts.clear(); }
            loadPDFFile(uri);
        } else if (mime.contains("djvu") || mime.contains("djv")) {
            currentFileFormat = "djvu";
            loadDjVuFile(uri);
        } else if (mime.contains("epub")) {
            currentFileFormat = "epub";
            loadEPUBFile(uri);
        } else if (mime.contains("fictionbook") || mime.contains("fb2")) {
            currentFileFormat = "fb2";
            loadFB2File(uri);
        } else if (mime.contains("wordprocessingml") || mime.contains("docx")) {
            currentFileFormat = "docx";
            loadDOCXFile(uri);
        } else if (mime.contains("msword") || mime.contains(".doc")) {
            currentFileFormat = "doc";
            loadDOCFile(uri);
        } else if (mime.contains("opendocument") || mime.contains("odt")) {
            currentFileFormat = "odt";
            loadODTFile(uri);
        } else if (mime.contains("rtf")) {
            currentFileFormat = "rtf";
            loadRTFFile(uri);
        } else if (mime.contains("markdown") || mime.contains("/md")) {
            currentFileFormat = "md";
            loadMarkdownFile(uri);
        } else if (mime.contains("html") || mime.contains("htm")) {
            currentFileFormat = "html";
            loadHTMLFile(uri);
        } else if (mime.startsWith("image/") && !mime.contains("djvu")) {
            insertImageToEditor(uri);
            return;
        } else {
            currentSaveUri = uri;
            currentFileFormat = "txt";
            loadTXTFile(uri);
        }

        addToLibrary(path, currentFileFormat);
        restoreReadingProgress(path);
    }

    // [R8] File size guard — prevents OOM from huge files
    private boolean checkFileSizeAllowed(Uri uri, String mime) {
        try {
            android.database.Cursor cursor = getContentResolver().query(
                uri, new String[]{ android.provider.OpenableColumns.SIZE }, null, null, null);
            if (cursor != null) {
                if (cursor.moveToFirst()) {
                    int sizeCol = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE);
                    if (sizeCol >= 0 && !cursor.isNull(sizeCol)) {
                        long size = cursor.getLong(sizeCol);
                        cursor.close();

                        long limit;
                        if (mime.contains("pdf"))      limit = MAX_PDF_FILE_BYTES;
                        else if (mime.contains("doc")) limit = MAX_DOC_FILE_BYTES;
                        else                           limit = MAX_TEXT_FILE_BYTES;

                        if (size > limit) {
                            long mb = size / (1024 * 1024);
                            long limitMb = limit / (1024 * 1024);
                            Log.w(TAG, "File too large: " + mb + "MB > " + limitMb + "MB");
                            showBridgeToast("Файл слишком большой (" + mb + " МБ). Максимум " + limitMb + " МБ.");
                            return false;
                        }
                        Log.d(TAG, "File size OK: " + (size/1024) + " KB");
                        return true;
                    }
                }
                cursor.close();
            }
        } catch (Exception e) {
            Log.w(TAG, "Cannot check file size: " + e.getMessage());
        }
        return true; // allow if size unknown
    }

    // ── Database helpers ──────────────────────────────────────────────────────
    private void addToLibrary(String path, String format) {
        dbExecutor.execute(() -> {
            try {
                AppDatabase.LibraryEntry entry = db.libraryDao().getByPath(path);
                if (entry == null) {
                    entry = new AppDatabase.LibraryEntry();
                    entry.filePath = path;
                    entry.format = format;
                    entry.addedAt = System.currentTimeMillis();
                    // FIX-1.5: use DISPLAY_NAME — content:// URIs end in
                    // a numeric document ID, not the filename.
                    String displayName = null;
                    try {
                        android.database.Cursor c2 = getContentResolver().query(
                            uri,
                            new String[]{ android.provider.OpenableColumns.DISPLAY_NAME },
                            null, null, null);
                        if (c2 != null) {
                            if (c2.moveToFirst()) {
                                int col = c2.getColumnIndex(
                                    android.provider.OpenableColumns.DISPLAY_NAME);
                                if (col >= 0) displayName = c2.getString(col);
                            }
                            c2.close();
                        }
                    } catch (Exception ignored) {}
                    if (displayName == null || displayName.isEmpty()) {
                        // Fallback: last path segment
                        String[] parts2 = path.split("/");
                        displayName = parts2[parts2.length - 1];
                    }
                    entry.title = displayName;
                }
                entry.lastOpenedAt = System.currentTimeMillis();
                db.libraryDao().insert(entry);
            } catch (Exception e) {
                Log.e(TAG, "addToLibrary error", e);
            }
        });
    }

    private void restoreReadingProgress(String path) {
        dbExecutor.execute(() -> {
            try {
                AppDatabase.ReadingProgress progress = db.readingProgressDao().get(path);
                if (progress != null) {
                    final int page = progress.page;
                    final int scrollY = progress.scrollY;
                    runOnUiThread(() ->
                        webView.evaluateJavascript(
                            "window.restorePosition(" + page + "," + scrollY + ")", null));
                }
            } catch (Exception e) {
                Log.e(TAG, "restoreReadingProgress error", e);
            }
        });
    }

    private void saveReadingProgress() {
        String path = currentFilePath;
        if (path == null) return;
        long elapsed = System.currentTimeMillis() - readingStartMs;
        readingStartMs = System.currentTimeMillis();

        webView.evaluateJavascript("window.getCurrentPosition()", value -> {
            dbExecutor.execute(() -> {
                try {
                    if (value == null || value.equals("null")) return;
                    int page = 0, scrollY = 0;
                    String clean = value.replace("\"", "");
                    if (clean.contains("page")) {
                        try { page = Integer.parseInt(clean.replaceAll(".*page:(\\d+).*", "$1")); }
                        catch (Exception ignore) {}
                    }
                    if (clean.contains("scrollY")) {
                        try { scrollY = Integer.parseInt(clean.replaceAll(".*scrollY:(\\d+).*", "$1")); }
                        catch (Exception ignore) {}
                    }
                    AppDatabase.ReadingProgress p = new AppDatabase.ReadingProgress();
                    p.filePath = path; p.page = page; p.scrollY = scrollY;
                    p.lastReadAt = System.currentTimeMillis();
                    db.readingProgressDao().save(p);
                    if (elapsed > 1000) db.readingProgressDao().addTime(path, elapsed);
                } catch (Exception e) {
                    Log.e(TAG, "saveReadingProgress error", e);
                }
            });
        });
    }

    // ── Format loaders ────────────────────────────────────────────────────────

    void loadTXTFile(Uri uri) {
        Log.d(TAG, "loadTXTFile");
        new Thread(() -> {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new IOException("Cannot open TXT file");
                String content = new String(readAllBytes(is), StandardCharsets.UTF_8);

                final int CHUNK = 500;
                String[] lines = content.split("\n", -1);
                if (lines.length <= CHUNK) {
                    String esc = jsEscape(content);
                    runOnUiThread(() -> webView.evaluateJavascript(
                        "window.loadTXTContent(`" + esc + "`)", null));
                } else {
                    StringBuilder first = new StringBuilder();
                    for (int i = 0; i < Math.min(CHUNK, lines.length); i++) {
                        if (i > 0) first.append('\n');
                        first.append(lines[i]);
                    }
                    String esc0 = jsEscape(first.toString());
                    runOnUiThread(() -> webView.evaluateJavascript(
                        "window.loadTXTContent(`" + esc0 + "`)", null));
                    for (int start = CHUNK; start < lines.length; start += CHUNK) {
                        int end = Math.min(start + CHUNK, lines.length);
                        StringBuilder chunk = new StringBuilder();
                        for (int i = start; i < end; i++) {
                            if (i > start) chunk.append('\n');
                            chunk.append(lines[i]);
                        }
                        String escC = jsEscape(chunk.toString());
                        runOnUiThread(() -> webView.evaluateJavascript(
                            "window.appendTXTContent(`" + escC + "`)", null));
                    }
                }
            } catch (OutOfMemoryError oom) {
                Log.e(TAG, "OOM loading TXT");
                showBridgeToast("Файл слишком большой");
            } catch (Exception e) {
                Log.e(TAG, "loadTXTFile error", e);
                showBridgeToast("Ошибка TXT: " + e.getMessage());
            }
        }).start();
    }

    void loadRTFFile(Uri uri) {
        Log.d(TAG, "loadRTFFile");
        new Thread(() -> {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new IOException("Cannot open RTF");
                String raw = new String(readAllBytes(is), StandardCharsets.ISO_8859_1);
                String text = raw
                    .replaceAll("\\\\[a-z]+[-]?\\d*[ ]?", " ")
                    .replaceAll("[{}]", "")
                    .replaceAll("\\s{2,}", "\n")
                    .trim();
                String esc = jsEscape(text);
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.loadTXTContent(`" + esc + "`)", null));
            } catch (Exception e) {
                Log.e(TAG, "loadRTFFile error", e);
                showBridgeToast("Ошибка RTF: " + e.getMessage());
            }
        }).start();
    }

    void loadMarkdownFile(Uri uri) {
        Log.d(TAG, "loadMarkdownFile");
        new Thread(() -> {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new IOException("Cannot open MD");
                String md = new String(readAllBytes(is), StandardCharsets.UTF_8);
                String esc = jsEscape(md);
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.loadMarkdownContent(`" + esc + "`)", null));
            } catch (Exception e) {
                Log.e(TAG, "loadMarkdownFile error", e);
                showBridgeToast("Ошибка MD: " + e.getMessage());
            }
        }).start();
    }

    void loadHTMLFile(Uri uri) {
        Log.d(TAG, "loadHTMLFile");
        new Thread(() -> {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new IOException("Cannot open HTML");
                String html = new String(readAllBytes(is), StandardCharsets.UTF_8);
                html = html.replaceAll("(?si)<script[^>]*>.*?</script>", "");
                String esc = jsEscape(html);
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.loadHTMLRaw(`" + esc + "`)", null));
            } catch (Exception e) {
                Log.e(TAG, "loadHTMLFile error", e);
                showBridgeToast("Ошибка HTML: " + e.getMessage());
            }
        }).start();
    }

    void loadEPUBFile(Uri uri) {
        Log.d(TAG, "loadEPUBFile");
        runOnUiThread(() -> webView.evaluateJavascript("window.showLoading('Открываю EPUB...')", null));
        new Thread(() -> {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new IOException("Cannot open EPUB");
                EpubReader reader = new EpubReader();
                Book book = reader.readEpub(is);
                StringBuilder sb = new StringBuilder();
                sb.append("<h1>").append(escHtml(book.getTitle())).append("</h1>\n");
                for (SpineReference spineRef : book.getSpine().getSpineReferences()) {
                    Resource res = spineRef.getResource();
                    if (res != null) {
                        String content = new String(res.getData(), StandardCharsets.UTF_8);
                        content = content
                            .replaceAll("(?si)<head[^>]*>.*?</head>", "")
                            .replaceAll("<br\\s*/?>", "\n")
                            .replaceAll("</p>", "\n\n")
                            .replaceAll("</div>", "\n")
                            .replaceAll("<h[1-6][^>]*>", "\n")
                            .replaceAll("</h[1-6]>", "\n\n")
                            .replaceAll("<[^>]+>", "")
                            .replaceAll("&amp;", "&").replaceAll("&lt;", "<")
                            .replaceAll("&gt;", ">").replaceAll("&nbsp;", " ")
                            .replaceAll("\\s{3,}", "\n\n").trim();
                        sb.append(content).append("\n\n");
                    }
                }
                String esc = jsEscape(sb.toString());
                runOnUiThread(() -> {
                    webView.evaluateJavascript("window.hideLoading()", null);
                    webView.evaluateJavascript("window.loadTXTContent(`" + esc + "`)", null);
                    webView.evaluateJavascript("window.showToast('EPUB открыт')", null);
                });
            } catch (Exception e) {
                Log.e(TAG, "loadEPUBFile error", e);
                runOnUiThread(() -> webView.evaluateJavascript("window.hideLoading()", null));
                showBridgeToast("Ошибка EPUB: " + e.getMessage());
            }
        }).start();
    }

    void loadFB2File(Uri uri) {
        Log.d(TAG, "loadFB2File");
        new Thread(() -> {
            try {
                InputStream rawIs = getContentResolver().openInputStream(uri);
                if (rawIs == null) throw new IOException("Cannot open FB2");

                XmlPullParser xpp = android.util.Xml.newPullParser();
                xpp.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
                xpp.setInput(rawIs, null);

                StringBuilder body = new StringBuilder(16384);
                String bookTitle = null;
                StringBuilder authorName = new StringBuilder();

                boolean inDescription=false, inBody=false, inBinary=false;
                boolean inBookTitle=false, inFirstName=false, inMiddleName=false;
                boolean inLastName=false, inAnnotation=false, inSectionTitle=false;
                boolean inEpigraph=false, inCite=false, inPoem=false, inP=false;
                int sectionDepth = 0;

                int eventType = xpp.getEventType();
                while (eventType != XmlPullParser.END_DOCUMENT) {
                    String tag = null;
                    if (eventType == XmlPullParser.START_TAG || eventType == XmlPullParser.END_TAG) {
                        tag = xpp.getName();
                        if (tag == null) tag = "";
                        int colon = tag.indexOf(':');
                        if (colon >= 0) tag = tag.substring(colon + 1);
                        tag = tag.toLowerCase();
                    }
                    if (eventType == XmlPullParser.START_TAG) {
                        switch (tag) {
                            case "description": inDescription=true; break;
                            case "body":        inBody=true; break;
                            case "binary":      inBinary=true; break;
                            case "book-title":  if(inDescription) inBookTitle=true; break;
                            case "annotation":  if(inDescription) inAnnotation=true; break;
                            case "first-name":  if(inDescription) inFirstName=true; break;
                            case "middle-name": if(inDescription) inMiddleName=true; break;
                            case "last-name":   if(inDescription) inLastName=true; break;
                            case "section":
                                if(inBody){ sectionDepth++;
                                  if(sectionDepth==1&&body.length()>0) body.append("\n\n"); } break;
                            case "title":   if(inBody){inSectionTitle=true;body.append("\n");} break;
                            case "subtitle": if(inBody){inP=true;} break;
                            case "epigraph": if(inBody){inEpigraph=true;body.append("\n");} break;
                            case "cite":    if(inBody){inCite=true;body.append("\n  ");} break;
                            case "poem":    if(inBody){inPoem=true;body.append("\n");} break;
                            case "stanza":  if(inBody) body.append("\n"); break;
                            case "p": case "v": case "th": case "td":
                                if(inBody&&!inAnnotation) inP=true; break;
                            case "empty-line": if(inBody) body.append("\n"); break;
                        }
                    } else if (eventType == XmlPullParser.END_TAG) {
                        switch (tag) {
                            case "description": inDescription=false; break;
                            case "body":        inBody=false; break;
                            case "binary":      inBinary=false; break;
                            case "book-title":  inBookTitle=false; break;
                            case "annotation":  inAnnotation=false; break;
                            case "first-name":  inFirstName=false; break;
                            case "middle-name": inMiddleName=false; break;
                            case "last-name":   inLastName=false; break;
                            case "section":     if(inBody&&sectionDepth>0) sectionDepth--; break;
                            case "title":       if(inBody){inSectionTitle=false;body.append("\n");} break;
                            case "epigraph":    if(inBody){inEpigraph=false;body.append("\n");} break;
                            case "cite":        if(inBody){inCite=false;body.append("\n");} break;
                            case "poem":        if(inBody){inPoem=false;body.append("\n");} break;
                            case "p": case "v": case "th": case "td":
                                if(inBody&&inP){body.append("\n");inP=false;} break;
                        }
                    } else if (eventType == XmlPullParser.TEXT) {
                        String t = xpp.getText();
                        if (t==null||t.isEmpty()) { eventType=xpp.next(); continue; }
                        if (inBinary||inAnnotation) { eventType=xpp.next(); continue; }
                        if (inDescription && !inBody) {
                            String tr = t.trim();
                            if (!tr.isEmpty()) {
                                if (inBookTitle) bookTitle = tr;
                                else if (inFirstName||inMiddleName||inLastName) {
                                    if (authorName.length()>0) authorName.append(" ");
                                    authorName.append(tr);
                                }
                            }
                            eventType=xpp.next(); continue;
                        }
                        if (inBody) body.append(t);
                    }
                    eventType = xpp.next();
                }
                rawIs.close();

                StringBuilder result = new StringBuilder();
                if (bookTitle!=null&&!bookTitle.isEmpty()) result.append(bookTitle).append("\n\n");
                String author = authorName.toString().trim();
                if (!author.isEmpty()) result.append(author).append("\n\n");
                result.append(body);

                String clean = result.toString()
                    .replaceAll("(?m)^[ \\t]+$", "")
                    .replaceAll("\\n{3,}", "\n\n")
                    .trim();

                if (clean.isEmpty()) { showBridgeToast("FB2: текст не найден"); return; }

                String esc = jsEscape(clean);
                runOnUiThread(() -> {
                    webView.evaluateJavascript("window.loadTXTContent(`" + esc + "`)", null);
                    webView.evaluateJavascript("window.showToast('FB2 открыт')", null);
                });
            } catch (Exception e) {
                Log.e(TAG, "loadFB2File error", e);
                showBridgeToast("Ошибка FB2: " + e.getMessage());
            }
        }).start();
    }

    void loadODTFile(Uri uri) {
        Log.d(TAG, "loadODTFile");
        new Thread(() -> {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new IOException("Cannot open ODT");
                String content = null;
                ZipInputStream zip = new ZipInputStream(is);
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    if ("content.xml".equals(entry.getName())) {
                        content = new String(readAllBytes(zip), StandardCharsets.UTF_8);
                        break;
                    }
                }
                zip.close();
                if (content == null) throw new IOException("content.xml not found");
                String text = content
                    .replaceAll("<text:p[^>]*>", "\n")
                    .replaceAll("<text:h[^>]*>", "\n")
                    .replaceAll("<text:line-break[^>]*/?>", "\n")
                    .replaceAll("<[^>]+>", "")
                    .replaceAll("&amp;","&").replaceAll("&lt;","<")
                    .replaceAll("&gt;",">").replaceAll("&quot;","\"")
                    .replaceAll("\\s{3,}", "\n\n").trim();
                String esc = jsEscape(text);
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.loadTXTContent(`" + esc + "`)", null));
            } catch (Exception e) {
                Log.e(TAG, "loadODTFile error", e);
                showBridgeToast("Ошибка ODT: " + e.getMessage());
            }
        }).start();
    }

    void loadDOCXFile(Uri uri) {
        Log.d(TAG, "loadDOCXFile");
        new Thread(() -> {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new IOException("Cannot open DOCX");
                String xmlContent = null;
                ZipInputStream zip = new ZipInputStream(is);
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    if ("word/document.xml".equals(entry.getName())) {
                        xmlContent = new String(readAllBytes(zip), StandardCharsets.UTF_8);
                        break;
                    }
                }
                zip.close();
                if (xmlContent == null) throw new IOException("document.xml not found");
                StringBuilder text = new StringBuilder();
                int pos = 0;
                while (pos < xmlContent.length()) {
                    int tagStart = xmlContent.indexOf('<', pos); if (tagStart < 0) break;
                    int tagEnd = xmlContent.indexOf('>', tagStart); if (tagEnd < 0) break;
                    String tag = xmlContent.substring(tagStart + 1, tagEnd).trim();
                    if (tag.equals("w:p")||tag.startsWith("w:p ")) {
                        if (text.length()>0) text.append('\n');
                    }
                    if (tag.equals("w:t")||tag.startsWith("w:t ")) {
                        int textEnd = xmlContent.indexOf("</w:t>", tagEnd);
                        if (textEnd>0) text.append(xmlContent, tagEnd+1, textEnd);
                    }
                    pos = tagEnd + 1;
                }
                String esc = jsEscape(text.toString());
                runOnUiThread(() -> {
                    webView.evaluateJavascript("window.loadTXTContent(`" + esc + "`)", null);
                    webView.evaluateJavascript("window.showToast('DOCX открыт')", null);
                });
            } catch (Exception e) {
                Log.e(TAG, "loadDOCXFile error", e);
                showBridgeToast("Ошибка DOCX: " + e.getMessage());
            }
        }).start();
    }

    void loadDOCFile(Uri uri) {
        Log.d(TAG, "loadDOCFile");
        new Thread(() -> {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new IOException("Cannot open DOC");
                HWPFDocument doc = new HWPFDocument(is);
                WordExtractor extractor = new WordExtractor(doc);
                String text = extractor.getText();
                extractor.close(); doc.close(); is.close();
                String esc = jsEscape(text);
                runOnUiThread(() -> {
                    webView.evaluateJavascript("window.loadTXTContent(`" + esc + "`)", null);
                    webView.evaluateJavascript("window.showToast('DOC открыт')", null);
                });
            } catch (Exception e) {
                Log.e(TAG, "loadDOCFile error", e);
                showBridgeToast("Ошибка DOC: " + e.getMessage());
            }
        }).start();
    }

    void loadPDFFile(Uri uri) {
        // [M3] Block double-open
        if (pdfLoading) { showBridgeToast("PDF уже загружается…"); return; }
        pdfLoading = true;
        Log.d(TAG, "loadPDFFile start");

        runOnUiThread(() -> webView.evaluateJavascript("window.showLoading('Открываю PDF...')", null));

        new Thread(() -> {
            ParcelFileDescriptor pfd = null; PdfRenderer renderer = null;
            try {
                pfd = getContentResolver().openFileDescriptor(uri, "r");
                if (pfd == null) throw new IOException("Cannot open PDF descriptor");
                renderer = new PdfRenderer(pfd);
                final int total = renderer.getPageCount();
                // Lazy: render only first PDF_INITIAL_PAGES on open
                final int toRender = Math.min(total, PDF_INITIAL_PAGES);
                Log.d(TAG, "PDF total=" + total + " initial=" + toRender);

                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.startPDFLoad(" + total + ")", null));

                for (int i = 0; i < toRender; i++) {
                    final int idx = i;
                    PdfRenderer.Page page = null; Bitmap bmp = null;
                    try {
                        page = renderer.openPage(i);
                        // Safe capped scale — no OOM
                        float scale = Math.min(1.0f,
                            (float) PDF_BASE_WIDTH / Math.max(page.getWidth(), 1));
                        int bw = Math.max(1, (int)(page.getWidth()  * scale));
                        int bh = Math.max(1, (int)(page.getHeight() * scale));
                        bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
                        new Canvas(bmp).drawColor(Color.WHITE);
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        bmp.compress(Bitmap.CompressFormat.JPEG, PDF_JPEG_QUALITY, baos);
                        String b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
                        runOnUiThread(() -> webView.evaluateJavascript(
                            "window.appendPDFPage(`" + b64 + "`," + (idx+1) + "," + total + ")", null));
                    } catch (OutOfMemoryError oom) {
                        // [M5] Graceful degradation
                        final int done = idx;
                        Log.e(TAG, "OOM rendering PDF page " + idx);
                        runOnUiThread(() -> {
                            webView.evaluateJavascript("window.endPDFLoad()", null);
                            webView.evaluateJavascript("window.showToast('Показано "
                                + done + " из " + total + " стр. (нехватка памяти)')", null);
                        });
                        return;
                    } finally {
                        if (bmp != null) bmp.recycle();
                        if (page != null) try { page.close(); } catch (Exception ignored) {}
                    }
                }
                renderer.close(); renderer = null;
                Log.d(TAG, "PDF render complete");
                runOnUiThread(() -> webView.evaluateJavascript("window.endPDFLoad()", null));
                extractPDFTextInBackground(uri, toRender);

            } catch (Exception e) {
                Log.e(TAG, "loadPDFFile error", e);
                runOnUiThread(() -> {
                    webView.evaluateJavascript("window.hideLoading()", null);
                    showBridgeToast("Ошибка PDF: " + e.getMessage());
                });
            } finally {
                if (renderer != null) try { renderer.close(); } catch (Exception ignored) {}
                if (pfd != null)      try { pfd.close();      } catch (IOException ignored) {}
                pdfLoading = false;
                Log.d(TAG, "loadPDFFile done, pdfLoading=false");
            }
        }).start();
    }

    // [R1] Limit PDF text cache to PDF_MAX_TEXT_PAGES to cap RAM
    private void extractPDFTextInBackground(Uri uri, int pageCount) {
        new Thread(() -> {
            try (InputStream is = getContentResolver().openInputStream(uri)) {
                if (is == null) return;
                PDDocument pdDoc = PDDocument.load(is);
                PDFTextStripper stripper = new PDFTextStripper();
                stripper.setSortByPosition(true);
                // [R1] Only cache up to PDF_MAX_TEXT_PAGES pages
                int pages = Math.min(pdDoc.getNumberOfPages(),
                    Math.min(pageCount, PDF_MAX_TEXT_PAGES));
                synchronized (pdfPageTexts) {
                    pdfPageTexts.clear();
                    for (int p = 1; p <= pages; p++) {
                        stripper.setStartPage(p); stripper.setEndPage(p);
                        try { pdfPageTexts.add(stripper.getText(pdDoc)); }
                        catch (Exception ignore) { pdfPageTexts.add(""); }
                    }
                }
                pdDoc.close();
                Log.d(TAG, "PDF text extracted: " + pages + " pages cached");
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.onPDFTextReady(" + pages + ")", null));
            } catch (Exception e) {
                Log.w(TAG, "PDF text extraction failed: " + e.getMessage());
            }
        }).start();
    }

    void loadDjVuFile(Uri uri) {
        if (!ensureDjVuLoaded()) {
            showBridgeToast("Библиотека DjVu не загружена. Пересоберите с NDK.");
            return;
        }
        Log.d(TAG, "loadDjVuFile");
        runOnUiThread(() -> webView.evaluateJavascript("window.showLoading('Открываю DjVu...')", null));

        new Thread(() -> {
            java.io.File tmp = null; long ctx = 0L; long doc = 0L;
            try {
                tmp = java.io.File.createTempFile("djvu_", ".djvu",
                    getApplicationContext().getCacheDir());
                try (InputStream is = getContentResolver().openInputStream(uri);
                     java.io.FileOutputStream fos = new java.io.FileOutputStream(tmp)) {
                    if (is == null) throw new IOException("Cannot open DjVu URI");
                    byte[] buf = new byte[8192]; int n;
                    while ((n = is.read(buf)) != -1) fos.write(buf, 0, n);
                }
                ctx = universe.constellation.orion.viewer.djvu.DjvuDocument.initContext();
                if (ctx == 0L) throw new RuntimeException("DjVu: cannot create context");

                universe.constellation.orion.viewer.pdf.DocInfo docInfo =
                    new universe.constellation.orion.viewer.pdf.DocInfo();
                doc = universe.constellation.orion.viewer.djvu.DjvuDocument.openFile(
                    tmp.getAbsolutePath(), ctx, docInfo);
                if (doc == 0L) {
                    universe.constellation.orion.viewer.djvu.DjvuDocument.destroy(ctx, 0L);
                    ctx = 0L;
                    throw new RuntimeException("DjVu: cannot open file");
                }
                final int totalPages = docInfo.pageCount;
                if (totalPages <= 0) throw new RuntimeException("DjVu: no pages");

                final int toRender = Math.min(totalPages, PDF_MAX_PREVIEW_PAGES);
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.startPDFLoad(" + totalPages + ")", null));

                for (int i = 0; i < toRender; i++) {
                    final int pageIdx = i;
                    universe.constellation.orion.viewer.PageSize ps =
                        new universe.constellation.orion.viewer.PageSize();
                    universe.constellation.orion.viewer.PageSize result =
                        universe.constellation.orion.viewer.djvu.DjvuDocument
                            .getPageDimension(ctx, doc, i, ps);
                    if (result == null || ps.width <= 0) continue;

                    float scale = Math.min(1.0f, (float) PDF_BASE_WIDTH / ps.width);
                    int bw = Math.max(1, (int)(ps.width  * scale));
                    int bh = Math.max(1, (int)(ps.height * scale));
                    Bitmap bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
                    try {
                        long pagePtr = universe.constellation.orion.viewer.djvu.DjvuDocument
                            .getPageInternal(ctx, doc, i);
                        if (pagePtr != 0L) {
                            universe.constellation.orion.viewer.djvu.DjvuDocument.drawPage(
                                ctx, doc, pagePtr, bmp, scale, bw, bh, 0, 0, bw, bh, 0, 0);
                            universe.constellation.orion.viewer.djvu.DjvuDocument.releasePage(pagePtr);
                        } else {
                            new Canvas(bmp).drawColor(Color.WHITE);
                        }
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        bmp.compress(Bitmap.CompressFormat.JPEG, PDF_JPEG_QUALITY, baos);
                        String b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
                        runOnUiThread(() -> webView.evaluateJavascript(
                            "window.appendPDFPage(`" + b64 + "`," + (pageIdx+1)
                                + "," + totalPages + ")", null));
                    } catch (OutOfMemoryError oom) {
                        Log.e(TAG, "OOM rendering DjVu page " + i);
                        final int done = i;
                        runOnUiThread(() -> {
                            webView.evaluateJavascript("window.endPDFLoad()", null);
                            webView.evaluateJavascript("window.showToast('Показано "
                                + done + " из " + totalPages + " стр.')", null);
                        });
                        return;
                    } finally {
                        if (bmp != null) bmp.recycle();
                    }
                }
                universe.constellation.orion.viewer.djvu.DjvuDocument.destroy(ctx, doc);
                ctx = 0L; doc = 0L;
                runOnUiThread(() -> {
                    webView.evaluateJavascript("window.endPDFLoad()", null);
                    webView.evaluateJavascript("window.showToast('DjVu открыт')", null);
                });
            } catch (Exception e) {
                Log.e(TAG, "loadDjVuFile error", e);
                if (doc != 0L && ctx != 0L) {
                    try { universe.constellation.orion.viewer.djvu.DjvuDocument.destroy(ctx, doc); }
                    catch (Exception ignored) {}
                } else if (ctx != 0L) {
                    try { universe.constellation.orion.viewer.djvu.DjvuDocument.destroy(ctx, 0L); }
                    catch (Exception ignored) {}
                }
                runOnUiThread(() -> webView.evaluateJavascript("window.hideLoading()", null));
                showBridgeToast("Ошибка DjVu: " + e.getMessage());
            } finally {
                if (tmp != null) tmp.delete();
            }
        }).start();
    }

    // ── Image insertion ───────────────────────────────────────────────────────
    void insertImageToEditor(Uri uri) {
        Log.d(TAG, "insertImageToEditor");
        new Thread(() -> {
            try {
                InputStream is = getContentResolver().openInputStream(uri);
                if (is == null) throw new IOException("Cannot open image");
                byte[] bytes = readAllBytes(is);
                String b64  = Base64.encodeToString(bytes, Base64.NO_WRAP);
                String mime = getContentResolver().getType(uri);
                if (mime == null || !mime.startsWith("image/")) mime = "image/jpeg";
                String dataUrl = "data:" + mime + ";base64," + b64;
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.insertImageDataUrl(`" + dataUrl + "`)", null));
            } catch (OutOfMemoryError oom) {
                Log.e(TAG, "OOM inserting image");
                showBridgeToast("Изображение слишком большое");
            } catch (Exception e) {
                Log.e(TAG, "insertImageToEditor error", e);
                showBridgeToast("Ошибка изображения: " + e.getMessage());
            }
        }).start();
    }

    // ── PDF text extraction for TTS / search ─────────────────────────────────
    void extractTextFromPDF(Uri uri) {
        runOnUiThread(() -> webView.evaluateJavascript("window.showLoading('Извлекаю текст...')", null));
        new Thread(() -> {
            try (InputStream is = getContentResolver().openInputStream(uri)) {
                if (is == null) throw new IOException("Cannot open PDF");
                PDDocument pdDoc = PDDocument.load(is);
                PDFTextStripper s = new PDFTextStripper(); s.setSortByPosition(true);
                String text; try { text = s.getText(pdDoc); } finally { pdDoc.close(); }
                if (text == null || text.trim().isEmpty()) {
                    showBridgeToast("Текст не найден в PDF");
                    runOnUiThread(() -> webView.evaluateJavascript("window.hideLoading()", null));
                    return;
                }
                String esc = jsEscape(text);
                runOnUiThread(() -> {
                    webView.evaluateJavascript("window.hideLoading()", null);
                    webView.evaluateJavascript("window.loadTXTContent(`" + esc + "`)", null);
                });
                currentSaveUri = null;
            } catch (Exception e) {
                Log.e(TAG, "extractTextFromPDF error", e);
                runOnUiThread(() -> webView.evaluateJavascript("window.hideLoading()", null));
                showBridgeToast("Ошибка: " + e.getMessage());
            }
        }).start();
    }

    // [M6] TTS for PDF — chunked speaking
    void extractTextAndSpeak(Uri uri) {
        runOnUiThread(() -> webView.evaluateJavascript("window.showLoading('TTS...')", null));
        new Thread(() -> {
            try (InputStream is = getContentResolver().openInputStream(uri)) {
                if (is == null) throw new IOException("Cannot open PDF for TTS");
                PDDocument pdDoc = PDDocument.load(is);
                PDFTextStripper stripper = new PDFTextStripper();
                stripper.setSortByPosition(true);
                String text;
                try { text = stripper.getText(pdDoc); } finally { pdDoc.close(); }
                runOnUiThread(() -> webView.evaluateJavascript("window.hideLoading()", null));
                if (text == null || text.trim().isEmpty()) {
                    showBridgeToast("Нет текста в PDF для TTS"); return;
                }
                if (!ttsReady) { showBridgeToast("TTS не готов"); return; }
                Locale lang = detectLanguage(text);
                startSpeaking(text, lang);
            } catch (Exception e) {
                Log.e(TAG, "extractTextAndSpeak error", e);
                runOnUiThread(() -> webView.evaluateJavascript("window.hideLoading()", null));
                showBridgeToast("TTS ошибка: " + e.getMessage());
            }
        }).start();
    }

    void searchInPDF(String term) {
        if (term == null || term.trim().isEmpty()) {
            runOnUiThread(() -> webView.evaluateJavascript("window.onPDFSearchResults([])", null));
            return;
        }
        new Thread(() -> {
            String lower = term.toLowerCase(Locale.ROOT);
            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            synchronized (pdfPageTexts) {
                for (int i = 0; i < pdfPageTexts.size(); i++) {
                    String pageText = pdfPageTexts.get(i);
                    String pageLower = pageText.toLowerCase(Locale.ROOT);
                    int count = 0, idx = 0;
                    while ((idx = pageLower.indexOf(lower, idx)) >= 0) { count++; idx += lower.length(); }
                    if (count > 0) {
                        int matchIdx = pageLower.indexOf(lower);
                        int es = Math.max(0, matchIdx - 30);
                        int ee = Math.min(pageText.length(), matchIdx + lower.length() + 40);
                        String excerpt = pageText.substring(es, ee)
                            .replace("\\","\\\\").replace("\"","\\\"")
                            .replace("\n"," ").trim();
                        if (!first) json.append(",");
                        json.append("{\"page\":").append(i+1)
                            .append(",\"count\":").append(count)
                            .append(",\"excerpt\":\"").append(excerpt).append("\"}");
                        first = false;
                    }
                }
            }
            json.append("]");
            String r = json.toString();
            runOnUiThread(() -> webView.evaluateJavascript("window.onPDFSearchResults(" + r + ")", null));
        }).start();
    }

    // ── Lazy PDF batch loader (FIX-1.1d) ────────────────────────────────────────
    // Called when user scrolls near the bottom of loaded pages.
    // Renders the next PDF_LOAD_BATCH pages and appends them to the editor.
    void loadPDFPagesBatch(Uri uri, int fromPage) {
        Uri curUri = currentPDFUri;
        if (curUri == null || pdfLoading) return;
        pdfLoading = true;
        Log.d(TAG, "loadPDFPagesBatch from=" + fromPage);

        new Thread(() -> {
            ParcelFileDescriptor pfd = null; PdfRenderer renderer = null;
            try {
                pfd = getContentResolver().openFileDescriptor(uri, "r");
                if (pfd == null) { pdfLoading = false; return; }
                renderer = new PdfRenderer(pfd);
                final int total = renderer.getPageCount();
                int startIdx = fromPage - 1; // fromPage is 1-based
                if (startIdx < 0) startIdx = 0;
                if (startIdx >= total) { pdfLoading = false; return; }
                int endIdx = Math.min(startIdx + PDF_LOAD_BATCH, total);
                Log.d(TAG, "Batch: pages " + (startIdx+1) + "–" + endIdx + " of " + total);

                for (int i = startIdx; i < endIdx; i++) {
                    final int idx = i;
                    PdfRenderer.Page page = null; Bitmap bmp = null;
                    try {
                        page = renderer.openPage(i);
                        float scale = Math.min(1.0f,
                            (float) PDF_BASE_WIDTH / Math.max(page.getWidth(), 1));
                        int bw = Math.max(1, (int)(page.getWidth()  * scale));
                        int bh = Math.max(1, (int)(page.getHeight() * scale));
                        bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
                        new Canvas(bmp).drawColor(Color.WHITE);
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                        bmp.compress(Bitmap.CompressFormat.JPEG, PDF_JPEG_QUALITY, baos);
                        String b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
                        runOnUiThread(() -> webView.evaluateJavascript(
                            "window.appendPDFPage(`" + b64 + "`," + (idx+1) + "," + total + ")", null));
                    } catch (OutOfMemoryError oom) {
                        Log.e(TAG, "OOM in batch at page " + i);
                        break;
                    } finally {
                        if (bmp != null) bmp.recycle();
                        if (page != null) try { page.close(); } catch (Exception ignored) {}
                    }
                }
                renderer.close(); renderer = null;
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.onPDFBatchLoaded(" + endIdx + "," + total + ")", null));
            } catch (Exception e) {
                Log.e(TAG, "loadPDFPagesBatch error", e);
            } finally {
                if (renderer != null) try { renderer.close(); } catch (Exception ignored) {}
                if (pfd != null)      try { pfd.close();      } catch (IOException ignored) {}
                pdfLoading = false;
            }
        }).start();
    }

    // ── PDF rerender on zoom ──────────────────────────────────────────────────
    void rerenderPDFPage(int pageIdx, int zoomPct) {
        Uri uri = currentPDFUri;
        if (uri == null) return;
        new Thread(() -> {
            ParcelFileDescriptor pfd = null; PdfRenderer renderer = null;
            PdfRenderer.Page page = null; Bitmap bmp = null;
            try {
                pfd = getContentResolver().openFileDescriptor(uri, "r");
                if (pfd == null) return;
                renderer = new PdfRenderer(pfd);
                if (pageIdx < 0 || pageIdx >= renderer.getPageCount()) return;
                page = renderer.openPage(pageIdx);
                int baseW = getHiresPdfWidth();
                float zoomFactor = Math.max(1.0f, zoomPct / 100.0f);
                int targetW = Math.min((int)(baseW * zoomFactor), baseW * 2);
                float scale = (float) targetW / Math.max(page.getWidth(), 1);
                int bw = Math.max(1, (int)(page.getWidth()  * scale));
                int bh = Math.max(1, (int)(page.getHeight() * scale));
                bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
                new Canvas(bmp).drawColor(Color.WHITE);
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.JPEG, PDF_JPEG_QUALITY, baos);
                String b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP);
                final int finalIdx = pageIdx;
                runOnUiThread(() -> webView.evaluateJavascript(
                    "window.updatePDFPageSrc(" + finalIdx + ",`" + b64 + "`)", null));
            } catch (OutOfMemoryError | Exception ignored) {
                Log.w(TAG, "rerenderPDFPage failed for page " + pageIdx);
            } finally {
                if (bmp  != null) bmp.recycle();
                if (page != null) try { page.close(); } catch (Exception ignored) {}
                if (renderer != null) try { renderer.close(); } catch (Exception ignored) {}
                if (pfd  != null) try { pfd.close();  } catch (IOException ignored) {}
            }
        }).start();
    }

    // ── Save ──────────────────────────────────────────────────────────────────
    void saveTXTToUri(Uri uri, String content) {
        new Thread(() -> {
            String mode = android.os.Build.VERSION.SDK_INT >= 29 ? "wt" : "w";
            try (OutputStream os = getContentResolver().openOutputStream(uri, mode)) {
                if (os == null) throw new IOException("Cannot open output stream");
                os.write(content.getBytes(StandardCharsets.UTF_8));
                showBridgeToast("Сохранено");
            } catch (Exception e) {
                Log.e(TAG, "saveTXTToUri error", e);
                try (OutputStream os2 = getContentResolver().openOutputStream(uri, "w")) {
                    if (os2 == null) throw new IOException("Write failed");
                    os2.write(content.getBytes(StandardCharsets.UTF_8));
                    showBridgeToast("Сохранено");
                } catch (Exception e2) { showBridgeToast("Ошибка: " + e2.getMessage()); }
            }
        }).start();
    }

    void generatePDFFromText(String text, Uri outputUri) {
        runOnUiThread(() -> webView.evaluateJavascript("window.showLoading('Создаю PDF...')", null));
        new Thread(() -> {
            final int PAGE_W=595, PAGE_H=842, MARGIN=72;
            final float FS=13f, LINE_H=FS*1.6f, TEXT_W=PAGE_W-MARGIN*2;
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setTextSize(FS); paint.setColor(Color.BLACK);
            paint.setTypeface(Typeface.create(Typeface.SERIF, Typeface.NORMAL));
            String[] rawLines = text.split("\n", -1);
            List<String> lines = new ArrayList<>();
            for (String raw : rawLines) {
                if (raw.trim().isEmpty()) { lines.add(""); continue; }
                String[] words = raw.split(" ", -1); StringBuilder cur = new StringBuilder();
                for (String w : words) {
                    String cand = cur.length()==0 ? w : cur+" "+w;
                    if (paint.measureText(cand)<=TEXT_W) cur=new StringBuilder(cand);
                    else { if(cur.length()>0) lines.add(cur.toString()); cur=new StringBuilder(w); }
                }
                if (cur.length()>0) lines.add(cur.toString());
            }
            PdfDocument doc = new PdfDocument(); int pageNum=1; float y=MARGIN+FS;
            PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(PAGE_W,PAGE_H,pageNum).create();
            PdfDocument.Page page = doc.startPage(info); Canvas canvas=page.getCanvas(); canvas.drawColor(Color.WHITE);
            for (String line : lines) {
                if (y+LINE_H>PAGE_H-MARGIN) {
                    doc.finishPage(page); pageNum++;
                    info=new PdfDocument.PageInfo.Builder(PAGE_W,PAGE_H,pageNum).create();
                    page=doc.startPage(info); canvas=page.getCanvas(); canvas.drawColor(Color.WHITE); y=MARGIN+FS;
                }
                if (!line.isEmpty()) canvas.drawText(line, MARGIN, y, paint);
                y += LINE_H;
            }
            doc.finishPage(page); final int fp=pageNum;
            try (OutputStream os = getContentResolver().openOutputStream(outputUri, "w")) {
                if (os==null) throw new IOException("Cannot write PDF");
                doc.writeTo(os);
                runOnUiThread(()->{
                    webView.evaluateJavascript("window.hideLoading()",null);
                    webView.evaluateJavascript("window.showToast('PDF: "+fp+" стр.')",null);
                });
            } catch (Exception e) {
                Log.e(TAG, "generatePDFFromText error", e);
                runOnUiThread(()->webView.evaluateJavascript("window.hideLoading()",null));
                showBridgeToast("Ошибка PDF: "+e.getMessage());
            } finally { doc.close(); }
        }).start();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private byte[] readAllBytes(InputStream is) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192]; int n;
        try { while ((n=is.read(chunk))!=-1) buf.write(chunk,0,n); }
        finally { is.close(); }
        return buf.toByteArray();
    }

    private byte[] readAllBytes(ZipInputStream zis) throws IOException {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        byte[] chunk = new byte[8192]; int n;
        while ((n=zis.read(chunk))!=-1) buf.write(chunk,0,n);
        return buf.toByteArray();
    }

    private String jsEscape(String s) {
        if (s==null) return "";
        return s.replace("\\","\\\\").replace("`","\\`").replace("$","\\$");
    }

    /** FIX-1.3/1.4: Resolves display name from URI and calls window.setCurrentDocInfo() in JS. */
    private void notifyDocInfo(Uri uri, String mime) {
        new Thread(() -> {
            String displayName = null;
            String path = uri.toString();
            try {
                android.database.Cursor c = getContentResolver().query(
                    uri, new String[]{ android.provider.OpenableColumns.DISPLAY_NAME },
                    null, null, null);
                if (c != null) {
                    if (c.moveToFirst()) {
                        int col = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                        if (col >= 0) displayName = c.getString(col);
                    }
                    c.close();
                }
            } catch (Exception ignored) {}
            if (displayName == null || displayName.isEmpty()) {
                String[] parts = path.split("/");
                displayName = parts[parts.length - 1];
                // Decode percent-encoded characters
                try { displayName = java.net.URLDecoder.decode(displayName, "UTF-8"); } catch (Exception ignored2) {}
            }
            // Derive simple format label
            String fmt = "txt";
            if (mime != null) {
                if (mime.contains("pdf")) fmt = "pdf";
                else if (mime.contains("epub")) fmt = "epub";
                else if (mime.contains("djvu")) fmt = "djvu";
                else if (mime.contains("wordprocessingml") || mime.contains("docx")) fmt = "docx";
                else if (mime.contains("msword")) fmt = "doc";
                else if (mime.contains("markdown")) fmt = "md";
                else if (mime.contains("html")) fmt = "html";
                else if (mime.contains("rtf")) fmt = "rtf";
                else if (mime.contains("opendocument")) fmt = "odt";
                else if (mime.contains("fb2") || mime.contains("fictionbook")) fmt = "fb2";
            }
            final String name = jsEscape(displayName);
            final String escapedPath = jsEscape(path);
            final String fmtFinal = fmt;
            runOnUiThread(() -> webView.evaluateJavascript(
                "window.setCurrentDocInfo(`" + escapedPath + "`,`" + name + "`,`" + fmtFinal + "`)", null));
        }).start();
    }

    private String escHtml(String s) {
        if (s==null) return "";
        return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }

    void showBridgeToast(String msg) {
        if (msg==null) msg="Неизвестная ошибка";
        String safe = msg.replace("\\","\\\\").replace("`","'");
        runOnUiThread(() -> webView.evaluateJavascript("window.showToast(`"+safe+"`)",null));
    }

    private void takePerm(Uri uri, boolean read, boolean write) {
        if (uri==null) return;
        try {
            int f=0;
            if (read)  f|=Intent.FLAG_GRANT_READ_URI_PERMISSION;
            if (write) f|=Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
            getContentResolver().takePersistableUriPermission(uri,f);
        } catch (SecurityException e) {
            Log.w(TAG, "takePerm failed: " + e.getMessage());
        }
    }

    // ── JS → Java Bridge ─────────────────────────────────────────────────────
    static class EditorBridge {
        private final WeakReference<MainActivity> ref;
        EditorBridge(MainActivity a) { this.ref=new WeakReference<>(a); }

        @JavascriptInterface public void openFile(String mimeTypes) {
            MainActivity a=ref.get(); if(a==null)return;
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("*/*");
            if (mimeTypes!=null&&!mimeTypes.isEmpty()&&!mimeTypes.equals("*/*"))
                i.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes.split(","));
            a.runOnUiThread(()->a.openAnyLauncher.launch(i));
        }

        @JavascriptInterface public void openTXT() {
            MainActivity a=ref.get(); if(a==null)return;
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/plain");
            a.runOnUiThread(()->a.openAnyLauncher.launch(i));
        }

        @JavascriptInterface public void openPDF() {
            MainActivity a=ref.get(); if(a==null)return;
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/pdf");
            a.runOnUiThread(()->a.openAnyLauncher.launch(i));
        }

        @JavascriptInterface public void openDOC() {
            MainActivity a=ref.get(); if(a==null)return;
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            });
            a.runOnUiThread(()->a.openAnyLauncher.launch(i));
        }

        @JavascriptInterface public void openEPUB() {
            MainActivity a=ref.get(); if(a==null)return;
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/epub+zip");
            a.runOnUiThread(()->a.openAnyLauncher.launch(i));
        }

        @JavascriptInterface public void openDJVU() {
            MainActivity a=ref.get(); if(a==null)return;
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("*/*");
            a.runOnUiThread(()->a.openAnyLauncher.launch(i));
        }

        @JavascriptInterface public void openImage() {
            MainActivity a=ref.get(); if(a==null)return;
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*");
            a.runOnUiThread(()->a.openImageLauncher.launch(i));
        }

        @JavascriptInterface public void save(String content) {
            MainActivity a=ref.get(); if(a==null)return;
            Uri uri=a.currentSaveUri;
            if (uri!=null) { a.saveTXTToUri(uri,content); }
            else {
                a.pendingSaveContent=content;
                Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TITLE,"document.txt");
                a.runOnUiThread(()->a.saveTXTLauncher.launch(i));
            }
        }

        @JavascriptInterface public void saveAs(String content) {
            MainActivity a=ref.get(); if(a==null)return;
            a.pendingSaveContent=content;
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("text/plain");
            i.putExtra(Intent.EXTRA_TITLE,"document.txt");
            a.runOnUiThread(()->a.saveAsLauncher.launch(i));
        }

        @JavascriptInterface public void savePDF() {
            MainActivity a=ref.get(); if(a==null)return;
            a.runOnUiThread(()->{
                PrintManager pm=(PrintManager)a.getSystemService(Activity.PRINT_SERVICE);
                PrintDocumentAdapter adapter=a.webView.createPrintDocumentAdapter("DocStudio");
                PrintAttributes attrs=new PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                    .setResolution(new PrintAttributes.Resolution("res","res",300,300))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
                pm.print("DocStudio",adapter,attrs);
            });
        }

        @JavascriptInterface public void convertTXTtoPDF(String text) {
            MainActivity a=ref.get(); if(a==null)return;
            a.pendingConvertText=text;
            Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/pdf");
            i.putExtra(Intent.EXTRA_TITLE,"document.pdf");
            a.runOnUiThread(()->a.savePDFDocLauncher.launch(i));
        }

        @JavascriptInterface public void convertPDFtoTXT() {
            MainActivity a=ref.get(); if(a==null)return;
            Uri pdf=a.currentPDFUri;
            if (pdf==null){a.showBridgeToast("PDF не открыт");return;}
            a.extractTextFromPDF(pdf);
        }

        @JavascriptInterface public void pdfEditMode() {
            MainActivity a=ref.get(); if(a==null)return;
            Uri pdf=a.currentPDFUri;
            if (pdf==null){a.showBridgeToast("PDF не открыт");return;}
            a.extractTextFromPDF(pdf);
        }

        @JavascriptInterface public void searchPDF(String term) {
            MainActivity a=ref.get(); if(a==null)return;
            synchronized(a.pdfPageTexts){
                if (a.pdfPageTexts.isEmpty()){a.showBridgeToast("Текст PDF ещё загружается...");return;}
            }
            a.searchInPDF(term);
        }

        @JavascriptInterface public void resetCurrentFile() {
            MainActivity a=ref.get(); if(a==null)return;
            a.currentSaveUri=null; a.currentPDFUri=null; a.currentFilePath=null;
            synchronized(a.pdfPageTexts){a.pdfPageTexts.clear();}
        }

        /**
         * Open an external URL or file path via Android Intent.
         * Used by hyperlinks of type "external" in the editor.
         * - http/https URLs → browser
         * - content:// or file:// URIs → appropriate viewer app
         */
        @JavascriptInterface public void openExternalLink(String url) {
            MainActivity a = ref.get(); if (a == null) return;
            if (url == null || url.isEmpty()) return;
            Log.d(TAG, "openExternalLink: " + url);
            a.runOnUiThread(() -> {
                try {
                    android.net.Uri uri;
                    android.content.Intent intent;
                    if (url.startsWith("http://") || url.startsWith("https://")) {
                        uri = android.net.Uri.parse(url);
                        intent = new android.content.Intent(
                            android.content.Intent.ACTION_VIEW, uri);
                    } else if (url.startsWith("content://") || url.startsWith("file://")) {
                        uri = android.net.Uri.parse(url);
                        intent = new android.content.Intent(
                            android.content.Intent.ACTION_VIEW);
                        intent.setDataAndType(uri, "*/*");
                        intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    } else {
                        // Treat as a file path — open via Files picker
                        a.showBridgeToast("Путь: " + url);
                        return;
                    }
                    intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                    if (intent.resolveActivity(a.getPackageManager()) != null) {
                        a.startActivity(intent);
                    } else {
                        a.showBridgeToast("Нет приложения для открытия: " + url);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "openExternalLink error", e);
                    a.showBridgeToast("Ошибка открытия ссылки");
                }
            });
        }

        /**
         * FIX BUG-1.1: Show a native Android input dialog (AlertDialog + EditText).
         *
         * WHY NATIVE: The HTML modal fails on Android because:
         *   1. Opening a keyboard via textarea.focus() inside a position:fixed overlay
         *      causes the WebView to resize, pushing the modal buttons off-screen.
         *   2. The fixed-position overlay then sits behind the keyboard, making
         *      "Создать" unreachable without scrolling.
         * Native AlertDialog is drawn ABOVE everything including the keyboard
         * and is unaffected by WebView layout changes.
         *
         * @param title       Dialog title text
         * @param defaultText Pre-filled text in the input field
         * @param jsCallback  JS function name to call with the result string.
         *                    Called as: window[jsCallback]("entered text")
         *                    or:        window[jsCallback](null) on cancel
         */
        @JavascriptInterface public void showNativeInputDialog(
                String title, String defaultText, String jsCallback) {
            MainActivity a = ref.get(); if (a == null) return;
            final String cb = jsCallback;
            a.runOnUiThread(() -> {
                android.app.AlertDialog.Builder builder =
                    new android.app.AlertDialog.Builder(a);
                builder.setTitle(title != null ? title : "Введите текст");

                android.widget.EditText input = new android.widget.EditText(a);
                input.setText(defaultText != null ? defaultText : "");
                input.setSelectAllOnFocus(true);
                input.setSingleLine(true);
                input.setInputType(
                    android.text.InputType.TYPE_CLASS_TEXT |
                    android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);

                // Add padding so text isn't flush with dialog edge
                int pad = (int)(16 * a.getResources().getDisplayMetrics().density);
                android.widget.FrameLayout container = new android.widget.FrameLayout(a);
                android.widget.FrameLayout.LayoutParams lp =
                    new android.widget.FrameLayout.LayoutParams(
                        android.widget.FrameLayout.LayoutParams.MATCH_PARENT,
                        android.widget.FrameLayout.LayoutParams.WRAP_CONTENT);
                lp.setMargins(pad, 0, pad, 0);
                input.setLayoutParams(lp);
                container.addView(input);
                builder.setView(container);

                builder.setPositiveButton("Создать", (dialog, which) -> {
                    String val = input.getText().toString().trim();
                    String safeVal = val.replace("\", "\\").replace(""", "\"");
                    a.runOnUiThread(() -> a.webView.evaluateJavascript(
                        "window." + cb + "("" + safeVal + "")", null));
                });
                builder.setNegativeButton("Отмена", (dialog, which) -> {
                    a.runOnUiThread(() -> a.webView.evaluateJavascript(
                        "window." + cb + "(null)", null));
                });
                builder.setOnCancelListener(dialog -> {
                    a.runOnUiThread(() -> a.webView.evaluateJavascript(
                        "window." + cb + "(null)", null));
                });

                android.app.AlertDialog dialog = builder.create();
                // Show keyboard immediately when dialog opens
                dialog.getWindow().setSoftInputMode(
                    android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
                dialog.show();

                // Request focus and position cursor at end
                input.requestFocus();
                input.setSelection(input.getText().length());
            });
        }

        // FIX-1.1d: Lazy PDF — load next batch of pages when user scrolls near end
        @JavascriptInterface public void loadMorePDFPages(int fromPage) {
            MainActivity a = ref.get(); if (a == null) return;
            Uri pdf = a.currentPDFUri; if (pdf == null) return;
            a.loadPDFPagesBatch(pdf, fromPage);
        }

        // FIX-1.6: Open a file stored in the library by its content URI path
        @JavascriptInterface public void openFileByPath(String uriString) {
            MainActivity a = ref.get(); if (a == null) return;
            if (uriString == null || uriString.isEmpty()) return;
            try {
                Uri uri = Uri.parse(uriString);
                Log.d(TAG, "openFileByPath: " + uriString);
                a.runOnUiThread(() -> a.openFileByUri(uri));
            } catch (Exception e) {
                Log.e(TAG, "openFileByPath error", e);
                a.showBridgeToast("Ошибка открытия: " + e.getMessage());
            }
        }

        // ── Bookmarks ──────────────────────────────────────────────────────────
        @JavascriptInterface public void addBookmark(int page, int scrollY, String title) {
            MainActivity a=ref.get(); if(a==null)return;
            String path=a.currentFilePath; if(path==null)return;
            a.dbExecutor.execute(()->{
                try {
                    AppDatabase.Bookmark b=new AppDatabase.Bookmark();
                    b.filePath=path; b.page=page; b.scrollY=scrollY;
                    b.title=title!=null&&!title.isEmpty()?title:"Стр. "+page;
                    b.createdAt=System.currentTimeMillis();
                    a.db.bookmarkDao().insert(b);
                    a.showBridgeToast("Закладка добавлена");
                } catch(Exception e){Log.e(TAG,"addBookmark error",e);}
            });
        }

        @JavascriptInterface public void getBookmarks() {
            MainActivity a=ref.get(); if(a==null)return;
            String path=a.currentFilePath;
            if (path==null){a.runOnUiThread(()->a.webView.evaluateJavascript("window.onBookmarks([])",null));return;}
            a.dbExecutor.execute(()->{
                try {
                    List<AppDatabase.Bookmark> list=a.db.bookmarkDao().getForFile(path);
                    String json=a.gson.toJson(list);
                    a.runOnUiThread(()->a.webView.evaluateJavascript("window.onBookmarks("+json+")",null));
                } catch(Exception e){Log.e(TAG,"getBookmarks error",e);}
            });
        }

        // ── Notes ──────────────────────────────────────────────────────────────
        @JavascriptInterface public void addNote(int page,String selectedText,String noteText,String color) {
            MainActivity a=ref.get(); if(a==null)return;
            String path=a.currentFilePath; if(path==null)return;
            a.dbExecutor.execute(()->{
                try {
                    AppDatabase.Note n=new AppDatabase.Note();
                    n.filePath=path; n.page=page; n.selectedText=selectedText;
                    n.noteText=noteText; n.color=color!=null?color:"#FFD700";
                    n.createdAt=n.updatedAt=System.currentTimeMillis();
                    long id=a.db.noteDao().insert(n);
                    a.runOnUiThread(()->a.webView.evaluateJavascript("window.onNoteAdded("+id+")",null));
                } catch(Exception e){Log.e(TAG,"addNote error",e);}
            });
        }

        @JavascriptInterface public void getNotes() {
            MainActivity a=ref.get(); if(a==null)return;
            String path=a.currentFilePath;
            if (path==null){a.runOnUiThread(()->a.webView.evaluateJavascript("window.onNotes([])",null));return;}
            a.dbExecutor.execute(()->{
                try {
                    List<AppDatabase.Note> list=a.db.noteDao().getForFile(path);
                    String json=a.gson.toJson(list);
                    a.runOnUiThread(()->a.webView.evaluateJavascript("window.onNotes("+json+")",null));
                } catch(Exception e){Log.e(TAG,"getNotes error",e);}
            });
        }

        // ── Library ────────────────────────────────────────────────────────────
        @JavascriptInterface public void getLibrary() {
            MainActivity a=ref.get(); if(a==null)return;
            a.dbExecutor.execute(()->{
                try {
                    List<AppDatabase.LibraryEntry> list=a.db.libraryDao().getAll();
                    String json=a.gson.toJson(list);
                    a.runOnUiThread(()->a.webView.evaluateJavascript("window.onLibrary("+json+")",null));
                } catch(Exception e){Log.e(TAG,"getLibrary error",e);}
            });
        }

        @JavascriptInterface public void searchLibrary(String q) {
            MainActivity a=ref.get(); if(a==null)return;
            a.dbExecutor.execute(()->{
                try {
                    List<AppDatabase.LibraryEntry> list=a.db.libraryDao().search(q);
                    String json=a.gson.toJson(list);
                    a.runOnUiThread(()->a.webView.evaluateJavascript("window.onLibrary("+json+")",null));
                } catch(Exception e){Log.e(TAG,"searchLibrary error",e);}
            });
        }

        @JavascriptInterface public void savePosition(int page,int scrollY) {
            MainActivity a=ref.get(); if(a==null)return;
            String path=a.currentFilePath; if(path==null)return;
            a.dbExecutor.execute(()->{
                try {
                    AppDatabase.ReadingProgress p=new AppDatabase.ReadingProgress();
                    p.filePath=path; p.page=page; p.scrollY=scrollY;
                    p.lastReadAt=System.currentTimeMillis();
                    a.db.readingProgressDao().save(p);
                } catch(Exception e){Log.e(TAG,"savePosition error",e);}
            });
        }

        // ── Search ─────────────────────────────────────────────────────────────
        @JavascriptInterface public void searchText(String term) {
            MainActivity a=ref.get(); if(a==null)return;
            a.runOnUiThread(()->{
                if(term==null||term.isEmpty()){a.webView.clearMatches();a.webView.evaluateJavascript("window.onSearchResults(0,0)",null);}
                else a.webView.findAllAsync(term);
            });
        }
        @JavascriptInterface public void searchNext(){MainActivity a=ref.get();if(a==null)return;a.runOnUiThread(()->a.webView.findNext(true));}
        @JavascriptInterface public void searchPrev(){MainActivity a=ref.get();if(a==null)return;a.runOnUiThread(()->a.webView.findNext(false));}
        @JavascriptInterface public void searchClear(){
            MainActivity a=ref.get();if(a==null)return;
            a.runOnUiThread(()->{a.webView.clearMatches();a.webView.evaluateJavascript("window.onSearchResults(0,0)",null);});
        }

        // ── TTS ────────────────────────────────────────────────────────────────
        @JavascriptInterface public void ttsSpeak(String text) {
            MainActivity a=ref.get(); if(a==null)return;
            if (!a.ttsReady){a.showBridgeToast("TTS инициализируется...");return;}
            if (text==null||text.trim().isEmpty()){a.showBridgeToast("Нет текста");return;}
            Locale lang=a.detectLanguage(text);
            a.startSpeaking(text, lang);  // [M6] chunked
        }

        @JavascriptInterface public void ttsSpeakPDF() {
            MainActivity a=ref.get(); if(a==null)return;
            Uri pdf=a.currentPDFUri; if(pdf==null){a.showBridgeToast("PDF не открыт");return;}
            a.extractTextAndSpeak(pdf);
        }

        @JavascriptInterface public void ttsStop() {
            MainActivity a=ref.get(); if(a==null)return;
            if (a.tts!=null) a.tts.stop();
            a.ttsChunks=new ArrayList<>(); a.ttsChunkIndex=0; // clear chunk queue
            a.ttsSpeaking=false;
            a.runOnUiThread(()->a.webView.evaluateJavascript("window.onTTSStateChange(false)",null));
        }

        @JavascriptInterface public void rerenderPDFPage(int pageIdx, int zoomPct) {
            MainActivity a=ref.get(); if(a==null)return;
            a.rerenderPDFPage(pageIdx, zoomPct);
        }
    }
}
