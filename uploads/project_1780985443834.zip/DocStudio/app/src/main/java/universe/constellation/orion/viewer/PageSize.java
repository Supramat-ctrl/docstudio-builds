package universe.constellation.orion.viewer;

/**
 * Data class passed to/from DjVu JNI native code.
 * The C code does: GetFieldID(cls, "width", "I") and GetFieldID(cls, "height", "I")
 * so the field names MUST match exactly.
 */
public class PageSize {
    public int width;
    public int height;

    public PageSize() {
        this.width  = 0;
        this.height = 0;
    }

    public PageSize(int width, int height) {
        this.width  = width;
        this.height = height;
    }
}
