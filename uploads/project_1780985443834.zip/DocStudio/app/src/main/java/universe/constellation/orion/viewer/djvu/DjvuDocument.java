package universe.constellation.orion.viewer.djvu;

import android.graphics.Bitmap;

import universe.constellation.orion.viewer.PageSize;
import universe.constellation.orion.viewer.pdf.DocInfo;

/**
 * Java wrapper for the DjVu native library (libdjvu.so).
 *
 * The JNI functions in djvu.c are named:
 *   Java_universe_constellation_orion_viewer_djvu_DjvuDocument_methodName
 *
 * so this class MUST be in package universe.constellation.orion.viewer.djvu
 * and named DjvuDocument for the native method lookup to succeed.
 *
 * All methods are static (called via jclass, not jobject) matching
 * the JNI function signatures in djvu.c.
 */
public class DjvuDocument {

    /**
     * One-time library load.
     * Called by DocStudio MainActivity when the DjVu feature is first used.
     * Using a separate init method (not static{}) lets MainActivity catch
     * UnsatisfiedLinkError gracefully instead of crashing on class load.
     */
    private static boolean sLibLoaded = false;

    public static boolean loadLibrary() {
        if (!sLibLoaded) {
            try {
                System.loadLibrary("djvu");
                sLibLoaded = true;
                // Must call initNative() once after loading the library
                // (sets up JVM global references in C code)
                initNative();
            } catch (UnsatisfiedLinkError e) {
                sLibLoaded = false;
            }
        }
        return sLibLoaded;
    }

    public static boolean isLoaded() { return sLibLoaded; }

    // ── Native methods — signatures must match djvu.c exactly ────────────────

    /**
     * Called once after System.loadLibrary to initialise JVM global refs in C.
     * Maps to: JNI_FN(DjvuDocument_initNative)
     */
    public static native void initNative();

    /**
     * Create a new DjVu context.
     * Returns: native pointer (cast to long) or 0 on failure.
     * Maps to: JNI_FN(DjvuDocument_initContext)
     */
    public static native long initContext();

    /**
     * Open a DjVu file.
     * @param filename  Absolute path to the .djvu file on disk
     * @param context   Pointer returned by initContext()
     * @param docInfo   DocInfo object; on return docInfo.pageCount is filled in
     * @return native document pointer or 0 on failure
     * Maps to: JNI_FN(DjvuDocument_openFile)
     * C signature: (JNIEnv*, jclass, jstring, jlong, jobject) -> jlong
     */
    public static native long openFile(String filename, long context, DocInfo docInfo);

    /**
     * Load a single page (returns a native page pointer).
     * Maps to: JNI_FN(DjvuDocument_getPageInternal)
     */
    public static native long getPageInternal(long context, long doc, int pageNum);

    /**
     * Get page width and height.
     * @param info  PageSize object; on return info.width and info.height are filled in.
     * @return the same info object, or null on error
     * Maps to: JNI_FN(DjvuDocument_getPageDimension)
     * C signature: (JNIEnv*, jclass, jlong, jlong, jint, jobject) -> jobject
     */
    public static native PageSize getPageDimension(long context, long doc, int pageNum, PageSize info);

    /**
     * Render a page into a Bitmap.
     * Maps to: JNI_FN(DjvuDocument_drawPage)
     */
    public static native boolean drawPage(
        long context, long doc, long page,
        Bitmap bitmap,
        float zoom,
        int bitmapWidth, int bitmapHeight,
        int patchX, int patchY,
        int patchW, int patchH,
        int originX, int originY
    );

    /**
     * Release a page pointer obtained from getPageInternal().
     * Maps to: JNI_FN(DjvuDocument_releasePage)
     */
    public static native void releasePage(long page);

    /**
     * Destroy the document and context.
     * Maps to: JNI_FN(DjvuDocument_destroy)
     */
    public static native void destroy(long context, long doc);
}
