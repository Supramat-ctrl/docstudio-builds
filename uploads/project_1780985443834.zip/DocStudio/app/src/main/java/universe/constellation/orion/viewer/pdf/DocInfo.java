package universe.constellation.orion.viewer.pdf;

/**
 * Data class passed to DjVu JNI openFile().
 * The C code does: GetFieldID(cls, "pageCount", "I")
 * so the field name MUST be "pageCount" exactly.
 */
public class DocInfo {
    public int pageCount;
    public String fileName;

    public DocInfo() {
        this.pageCount = 0;
        this.fileName  = "";
    }
}
