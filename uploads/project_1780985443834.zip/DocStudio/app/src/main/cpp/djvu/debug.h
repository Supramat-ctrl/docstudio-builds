#ifndef DJVU_DEBUG_H
#define DJVU_DEBUG_H
/* Stub debug header for DocStudio build */
#define DEBUG_PRINT(...)
#endif
