# Keep JS bridge methods
-keepclassmembers class com.docstudio.app.MainActivity$EditorBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# Keep pdfbox-android
-keep class com.tom_roush.** { *; }
-dontwarn com.tom_roush.**

# Keep Apache POI for DOC support
-keep class org.apache.poi.** { *; }
-dontwarn org.apache.poi.**
-dontwarn org.apache.xmlbeans.**
-dontwarn schemasMicrosoftComOfficeOffice.**
-dontwarn schemasMicrosoftComOfficeWord.**
