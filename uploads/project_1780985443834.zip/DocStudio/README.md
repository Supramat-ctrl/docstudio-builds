# DocStudio — Android Text & PDF Editor

## Описание
Полноценный текстовый редактор для Android с поддержкой:
- Открытие и сохранение **TXT** файлов (через SAF)
- Открытие **PDF** (рендеринг страниц через PdfRenderer)
- Сохранение **PDF** (через Android PrintManager)
- Вставка изображений **JPG/PNG**
- Форматирование текста (жирный, курсив, подчёркнутый, шрифты, размеры)
- Выравнивание текста
- Конвертация TXT → PDF и обратно

## Системные требования
- Android **8.0+** (minSdk 26)
- Android Studio **Hedgehog** (2023.1.1) или новее
- JDK 17
- Gradle 8.4

## Сборка в Android Studio

1. Распакуйте архив `DocStudio.zip`
2. Откройте Android Studio → **File → Open** → выберите папку `DocStudio`
3. Дождитесь синхронизации Gradle
4. Подключите устройство или запустите эмулятор
5. **Run → Run 'app'** (Shift+F10)

## Сборка через командную строку

```bash
# Debug APK
./gradlew assembleDebug

# Release APK
./gradlew assembleRelease
```

APK будет в: `app/build/outputs/apk/debug/app-debug.apk`

## Архитектура

```
MainActivity.java       — WebView + Android Bridge (SAF, PDF, Image)
EditorBridge (inner)    — @JavascriptInterface методы
assets/editor.html      — Весь UI редактора (HTML/CSS/JS)
```

## JavaScript ↔ Android Bridge

| JS вызов                  | Android метод       | Действие                    |
|---------------------------|---------------------|-----------------------------|
| `bridge('openTXT')`       | `openTXT()`         | SAF — открыть TXT           |
| `bridge('openPDF')`       | `openPDF()`         | SAF — открыть PDF           |
| `bridge('openImage')`     | `openImage()`       | SAF — выбрать изображение   |
| `bridge('saveTXT', text)` | `saveTXT(content)`  | SAF — сохранить TXT         |
| `bridge('savePDF')`       | `savePDF()`         | PrintManager → PDF          |

## Разрешения
- `READ_MEDIA_IMAGES` — чтение изображений (Android 13+)
- `READ_EXTERNAL_STORAGE` — чтение файлов (Android ≤12)
- `WRITE_EXTERNAL_STORAGE` — запись (Android ≤9)
- Файловый доступ через SAF не требует разрешений
